#!/usr/bin/env python3
"""Pack supplied attack art; ImageMagick handles raster export, Pillow reads QA data."""
from pathlib import Path
import json
import math
import subprocess
import tempfile
import numpy as np
from PIL import Image
from scipy import ndimage

ROOT = Path(__file__).resolve().parents[1]
PACK = ROOT / 'docs/poczta/od-grafika/40_smoki_ataki_v1'
SPECIES = {
    'ognisty': ('ziej', [1100, 1090, 1090]),
    'gorski': ('szpony', [1100, 1090, 1100]),
    'kwasowy': ('pluj', [1090, 1090, 1080]),
    'lesny': ('ugryzienie', [945, 945, 945]),
    'trujacy': ('dmuch', [1150, 1150, 1150]),
    'cien': ('ziej', [935, 935, 935]),
}
DIRECTIONS = ['bok', 'przod', 'tyl']
SNOUT_SIDE = {
    'ognisty': [(0.05,.24),(.02,.46),(.03,.48)],
    'gorski': [(.07,.55),(.18,.32),(.08,.54)],
    'kwasowy': [(.04,.45),(.02,.48),(.05,.42)],
    'lesny': [(.03,.53),(.02,.65),(.03,.53)],
    'trujacy': [(.04,.79),(.02,.69),(.04,.79)],
    'cien': [(.07,.40),(.02,.45),(.04,.49)],
}

def run(*args):
    subprocess.run([str(x) for x in args], check=True)

def components(path):
    with Image.open(path) as im:
        alpha = np.asarray(im.convert('RGBA'))[:, :, 3]
    labels, _ = ndimage.label(alpha > 200)
    boxes = []
    for label, slices in enumerate(ndimage.find_objects(labels), 1):
        if slices and np.count_nonzero(labels[slices] == label) > 2000:
            ys, xs = slices
            boxes.append((xs.start, ys.start, xs.stop, ys.stop))
    assert len(boxes) == 9, (path, len(boxes))
    boxes.sort(key=lambda b: (b[1] + b[3]) / 2)
    return [b for row in range(3) for b in sorted(boxes[row*3:row*3+3])]

def main():
    metadata = {'version': '40-G001-v1', 'scope': 'attack-only',
                'cell': [220, 200], 'anchor': [110, 170],
                'directionOrder': DIRECTIONS, 'columnOrder': ['anticipation', 'strike', 'recovery'],
                'durationsMs': [280, 160, 400], 'repeat': 0,
                'mirrorRightFromLeft': True, 'species': {}}
    qa = []
    with tempfile.TemporaryDirectory(prefix='smoki40-') as tmp:
        tmp = Path(tmp)
        for species, (action, rear_feet_y) in SPECIES.items():
            source = PACK / 'zrodla' / f'{species}.png'
            target = PACK / species
            target.mkdir(parents=True, exist_ok=True)
            boxes = components(source)
            entries = []
            for i, box in enumerate(boxes):
                x0, y0, x1, y1 = box
                ax = (x0 + x1) / 2
                # Pack the full silhouette first; rear tails must not shrink every view.
                # The actual support/body point is a separate per-frame renderOrigin.
                ay = y1 - 1
                entries.append((box, ax, ay))
            scale = min(min(100/(ax-x0), 100/(x1-ax), 160/(ay-y0),
                            24/max(y1-ay, 1)) for (x0,y0,x1,y1),ax,ay in entries)
            intermediate = []
            frames = []
            for i, ((x0,y0,x1,y1), ax, ay) in enumerate(entries):
                width, height = round((x1-x0)*scale), round((y1-y0)*scale)
                x, y = round(110-(ax-x0)*scale), round(170-(ay-y0)*scale)
                assert x >= 0 and y >= 0 and x+width <= 220 and y+height <= 200
                p = tmp / f'{species}-{i}.png'
                run('convert', source, '-crop', f'{x1-x0}x{y1-y0}+{x0}+{y0}', '+repage',
                    '-channel', 'A', '-threshold', '78%', '+channel',
                    '-filter', 'point', '-resize', f'{width}x{height}!',
                    '-background', 'none', '-gravity', 'northwest', '-splice', f'{x}x{y}',
                    '-extent', '220x200', p)
                intermediate.append(p)
                direction = DIRECTIONS[i//3]
                name = f'{action}_{direction}_{i%3+1}'
                support_y = y1-1 if i < 6 else rear_feet_y[i%3]
                if species == 'gorski':
                    support_y = y0+(y1-y0)*.78
                support = [110, round(y+(support_y-y0)*scale)]
                frames.append({'name': name, 'file': f'{species}/{name}.png',
                               'direction': direction, 'index': i%3+1,
                               'sourceBox': [x0,y0,x1-x0,y1-y0],
                               'sourceAnchor': [ax, ay], 'anchor': [110,170],
                               'renderAnchor':support,
                               'renderOrigin':[support[0]/220,support[1]/200],
                               'mouth': [round(x + width*(SNOUT_SIDE[species][i%3][0] if i<3 else .5)),
                                         round(y + height*(SNOUT_SIDE[species][i%3][1] if i<3 else (.85 if i<6 else .08)))],
                               'mouthPrecision': 'approximate; check effect alignment in game'})
            palette = tmp / f'{species}-palette.png'
            run('convert', *intermediate, '+append', '-background', '#1e1a24',
                '-alpha', 'remove', '-alpha', 'off', '+dither', '-colors', '15',
                '-unique-colors', palette)
            output = []
            for p, frame in zip(intermediate, frames):
                dest = PACK / frame['file']
                mask = tmp / 'mask.png'
                color = tmp / 'color.png'
                run('convert', p, '-alpha', 'extract', mask)
                run('convert', p, '-alpha', 'off', '+dither', '-remap', palette, color)
                run('convert', color, mask, '-alpha', 'off', '-compose', 'CopyOpacity',
                    '-composite', '-channel', 'A', '-threshold', '50%', '+channel', dest)
                with Image.open(dest) as im:
                    a = np.asarray(im.convert('RGBA'))
                    assert im.size == (220,200)
                    assert set(np.unique(a[:,:,3])) <= {0,255}
                    colors = len(np.unique(a[a[:,:,3]>0,:3], axis=0))
                    assert colors <= 15, colors
                    assert not a[0,:,3].any() and not a[-1,:,3].any()
                    assert not a[:,0,3].any() and not a[:,-1,3].any()
                    qa.append({'file':frame['file'], 'size':[220,200], 'opaqueColors':colors,
                               'binaryAlpha':True, 'borderClear':True})
                output.append(dest)
            run('montage', *output, '-tile', '3x3', '-geometry', '220x200+0+0',
                '-background', 'none', target/'atlas.png')
            for d, direction in enumerate(DIRECTIONS):
                paths = output[d*3:d*3+3]
                run('convert', '-background','#39404b','-alpha','remove','-alpha','off',
                    '-delay','28',paths[0],'-delay','16',paths[1],'-delay','65',paths[2],
                    '-loop','0',target/f'{action}_{direction}_podglad.gif')
            metadata['species'][species] = {'action': action, 'atlas':f'{species}/atlas.png',
                'atlasSize':[660,600], 'scaleFromSource':scale,
                'anchorType':'virtualGroundDuringFlight' if species=='gorski' else 'feet',
                'frames':frames}
        (PACK/'metadata.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n')
        (PACK/'QA.json').write_text(json.dumps({'frames':len(qa),'checks':qa},indent=2)+'\n')
    print(f'Exported and checked {len(qa)} frames, 6 atlases, 18 GIF previews.')

if __name__ == '__main__':
    main()
