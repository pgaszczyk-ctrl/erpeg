window.SMOKI40 = {
  "version": "40-G001-v1",
  "scope": "attack-only",
  "cell": [
    220,
    200
  ],
  "anchor": [
    110,
    170
  ],
  "directionOrder": [
    "bok",
    "przod",
    "tyl"
  ],
  "columnOrder": [
    "anticipation",
    "strike",
    "recovery"
  ],
  "durationsMs": [
    280,
    160,
    400
  ],
  "repeat": 0,
  "mirrorRightFromLeft": true,
  "species": {
    "ognisty": {
      "action": "ziej",
      "atlas": "ognisty/atlas.png",
      "atlasSize": [
        660,
        600
      ],
      "scaleFromSource": 0.4359673024523161,
      "anchorType": "feet",
      "frames": [
        {
          "name": "ziej_bok_1",
          "file": "ognisty/ziej_bok_1.png",
          "direction": "bok",
          "index": 1,
          "sourceBox": [
            60,
            67,
            331,
            298
          ],
          "sourceAnchor": [
            225.5,
            364
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            170
          ],
          "renderOrigin": [
            0.5,
            0.85
          ],
          "mouth": [
            45,
            72
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "ziej_bok_2",
          "file": "ognisty/ziej_bok_2.png",
          "direction": "bok",
          "index": 2,
          "sourceBox": [
            468,
            68,
            345,
            297
          ],
          "sourceAnchor": [
            640.5,
            364
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            170
          ],
          "renderOrigin": [
            0.5,
            0.85
          ],
          "mouth": [
            38,
            100
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "ziej_bok_3",
          "file": "ognisty/ziej_bok_3.png",
          "direction": "bok",
          "index": 3,
          "sourceBox": [
            894,
            68,
            333,
            297
          ],
          "sourceAnchor": [
            1060.5,
            364
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            170
          ],
          "renderOrigin": [
            0.5,
            0.85
          ],
          "mouth": [
            41,
            103
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "ziej_przod_1",
          "file": "ognisty/ziej_przod_1.png",
          "direction": "przod",
          "index": 1,
          "sourceBox": [
            33,
            427,
            355,
            324
          ],
          "sourceAnchor": [
            210.5,
            750
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            170
          ],
          "renderOrigin": [
            0.5,
            0.85
          ],
          "mouth": [
            110,
            149
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "ziej_przod_2",
          "file": "ognisty/ziej_przod_2.png",
          "direction": "przod",
          "index": 2,
          "sourceBox": [
            456,
            427,
            351,
            324
          ],
          "sourceAnchor": [
            631.5,
            750
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            170
          ],
          "renderOrigin": [
            0.5,
            0.85
          ],
          "mouth": [
            110,
            149
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "ziej_przod_3",
          "file": "ognisty/ziej_przod_3.png",
          "direction": "przod",
          "index": 3,
          "sourceBox": [
            873,
            427,
            354,
            324
          ],
          "sourceAnchor": [
            1050.0,
            750
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            170
          ],
          "renderOrigin": [
            0.5,
            0.85
          ],
          "mouth": [
            110,
            149
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "ziej_tyl_1",
          "file": "ognisty/ziej_tyl_1.png",
          "direction": "tyl",
          "index": 1,
          "sourceBox": [
            39,
            808,
            363,
            368
          ],
          "sourceAnchor": [
            220.5,
            1175
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            137
          ],
          "renderOrigin": [
            0.5,
            0.685
          ],
          "mouth": [
            110,
            23
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "ziej_tyl_2",
          "file": "ognisty/ziej_tyl_2.png",
          "direction": "tyl",
          "index": 2,
          "sourceBox": [
            452,
            821,
            363,
            355
          ],
          "sourceAnchor": [
            633.5,
            1175
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            133
          ],
          "renderOrigin": [
            0.5,
            0.665
          ],
          "mouth": [
            110,
            28
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "ziej_tyl_3",
          "file": "ognisty/ziej_tyl_3.png",
          "direction": "tyl",
          "index": 3,
          "sourceBox": [
            871,
            826,
            358,
            350
          ],
          "sourceAnchor": [
            1050.0,
            1175
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            133
          ],
          "renderOrigin": [
            0.5,
            0.665
          ],
          "mouth": [
            110,
            30
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        }
      ]
    },
    "gorski": {
      "action": "szpony",
      "atlas": "gorski/atlas.png",
      "atlasSize": [
        660,
        600
      ],
      "scaleFromSource": 0.45977011494252873,
      "anchorType": "virtualGroundDuringFlight",
      "frames": [
        {
          "name": "szpony_bok_1",
          "file": "gorski/szpony_bok_1.png",
          "direction": "bok",
          "index": 1,
          "sourceBox": [
            63,
            35,
            345,
            345
          ],
          "sourceAnchor": [
            235.5,
            379
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            136
          ],
          "renderOrigin": [
            0.5,
            0.68
          ],
          "mouth": [
            42,
            99
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "szpony_bok_2",
          "file": "gorski/szpony_bok_2.png",
          "direction": "bok",
          "index": 2,
          "sourceBox": [
            449,
            86,
            417,
            288
          ],
          "sourceAnchor": [
            657.5,
            373
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            141
          ],
          "renderOrigin": [
            0.5,
            0.705
          ],
          "mouth": [
            49,
            80
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "szpony_bok_3",
          "file": "gorski/szpony_bok_3.png",
          "direction": "bok",
          "index": 3,
          "sourceBox": [
            920,
            45,
            363,
            340
          ],
          "sourceAnchor": [
            1101.5,
            384
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            136
          ],
          "renderOrigin": [
            0.5,
            0.68
          ],
          "mouth": [
            40,
            98
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "szpony_przod_1",
          "file": "gorski/szpony_przod_1.png",
          "direction": "przod",
          "index": 1,
          "sourceBox": [
            38,
            414,
            382,
            314
          ],
          "sourceAnchor": [
            229.0,
            727
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            139
          ],
          "renderOrigin": [
            0.5,
            0.695
          ],
          "mouth": [
            110,
            148
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "szpony_przod_2",
          "file": "gorski/szpony_przod_2.png",
          "direction": "przod",
          "index": 2,
          "sourceBox": [
            484,
            418,
            353,
            349
          ],
          "sourceAnchor": [
            660.5,
            766
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            135
          ],
          "renderOrigin": [
            0.5,
            0.675
          ],
          "mouth": [
            110,
            146
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "szpony_przod_3",
          "file": "gorski/szpony_przod_3.png",
          "direction": "przod",
          "index": 3,
          "sourceBox": [
            901,
            417,
            380,
            341
          ],
          "sourceAnchor": [
            1091.0,
            757
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            136
          ],
          "renderOrigin": [
            0.5,
            0.68
          ],
          "mouth": [
            110,
            147
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "szpony_tyl_1",
          "file": "gorski/szpony_tyl_1.png",
          "direction": "tyl",
          "index": 1,
          "sourceBox": [
            43,
            808,
            384,
            342
          ],
          "sourceAnchor": [
            235.0,
            1149
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            136
          ],
          "renderOrigin": [
            0.5,
            0.68
          ],
          "mouth": [
            110,
            26
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "szpony_tyl_2",
          "file": "gorski/szpony_tyl_2.png",
          "direction": "tyl",
          "index": 2,
          "sourceBox": [
            450,
            826,
            417,
            314
          ],
          "sourceAnchor": [
            658.5,
            1139
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            139
          ],
          "renderOrigin": [
            0.5,
            0.695
          ],
          "mouth": [
            110,
            38
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "szpony_tyl_3",
          "file": "gorski/szpony_tyl_3.png",
          "direction": "tyl",
          "index": 3,
          "sourceBox": [
            895,
            808,
            389,
            346
          ],
          "sourceAnchor": [
            1089.5,
            1153
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            135
          ],
          "renderOrigin": [
            0.5,
            0.675
          ],
          "mouth": [
            110,
            24
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        }
      ]
    },
    "kwasowy": {
      "action": "pluj",
      "atlas": "kwasowy/atlas.png",
      "atlasSize": [
        660,
        600
      ],
      "scaleFromSource": 0.4177545691906005,
      "anchorType": "feet",
      "frames": [
        {
          "name": "pluj_bok_1",
          "file": "kwasowy/pluj_bok_1.png",
          "direction": "bok",
          "index": 1,
          "sourceBox": [
            28,
            63,
            390,
            319
          ],
          "sourceAnchor": [
            223.0,
            381
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            170
          ],
          "renderOrigin": [
            0.5,
            0.85
          ],
          "mouth": [
            36,
            97
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "pluj_bok_2",
          "file": "kwasowy/pluj_bok_2.png",
          "direction": "bok",
          "index": 2,
          "sourceBox": [
            455,
            85,
            415,
            292
          ],
          "sourceAnchor": [
            662.5,
            376
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            170
          ],
          "renderOrigin": [
            0.5,
            0.85
          ],
          "mouth": [
            26,
            107
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "pluj_bok_3",
          "file": "kwasowy/pluj_bok_3.png",
          "direction": "bok",
          "index": 3,
          "sourceBox": [
            907,
            63,
            377,
            318
          ],
          "sourceAnchor": [
            1095.5,
            380
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            170
          ],
          "renderOrigin": [
            0.5,
            0.85
          ],
          "mouth": [
            39,
            94
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "pluj_przod_1",
          "file": "kwasowy/pluj_przod_1.png",
          "direction": "przod",
          "index": 1,
          "sourceBox": [
            59,
            413,
            337,
            340
          ],
          "sourceAnchor": [
            227.5,
            752
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            170
          ],
          "renderOrigin": [
            0.5,
            0.85
          ],
          "mouth": [
            110,
            149
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "pluj_przod_2",
          "file": "kwasowy/pluj_przod_2.png",
          "direction": "przod",
          "index": 2,
          "sourceBox": [
            478,
            423,
            352,
            329
          ],
          "sourceAnchor": [
            654.0,
            751
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            170
          ],
          "renderOrigin": [
            0.5,
            0.85
          ],
          "mouth": [
            110,
            149
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "pluj_przod_3",
          "file": "kwasowy/pluj_przod_3.png",
          "direction": "przod",
          "index": 3,
          "sourceBox": [
            909,
            420,
            351,
            332
          ],
          "sourceAnchor": [
            1084.5,
            751
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            170
          ],
          "renderOrigin": [
            0.5,
            0.85
          ],
          "mouth": [
            110,
            150
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "pluj_tyl_1",
          "file": "kwasowy/pluj_tyl_1.png",
          "direction": "tyl",
          "index": 1,
          "sourceBox": [
            26,
            794,
            405,
            351
          ],
          "sourceAnchor": [
            228.5,
            1144
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            148
          ],
          "renderOrigin": [
            0.5,
            0.74
          ],
          "mouth": [
            110,
            36
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "pluj_tyl_2",
          "file": "kwasowy/pluj_tyl_2.png",
          "direction": "tyl",
          "index": 2,
          "sourceBox": [
            467,
            772,
            391,
            384
          ],
          "sourceAnchor": [
            662.5,
            1155
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            143
          ],
          "renderOrigin": [
            0.5,
            0.715
          ],
          "mouth": [
            110,
            23
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "pluj_tyl_3",
          "file": "kwasowy/pluj_tyl_3.png",
          "direction": "tyl",
          "index": 3,
          "sourceBox": [
            885,
            791,
            392,
            350
          ],
          "sourceAnchor": [
            1081.0,
            1140
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            145
          ],
          "renderOrigin": [
            0.5,
            0.725
          ],
          "mouth": [
            110,
            36
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        }
      ]
    },
    "lesny": {
      "action": "ugryzienie",
      "atlas": "lesny/atlas.png",
      "atlasSize": [
        660,
        600
      ],
      "scaleFromSource": 0.42462845010615713,
      "anchorType": "feet",
      "frames": [
        {
          "name": "ugryzienie_bok_1",
          "file": "lesny/ugryzienie_bok_1.png",
          "direction": "bok",
          "index": 1,
          "sourceBox": [
            80,
            60,
            417,
            267
          ],
          "sourceAnchor": [
            288.5,
            326
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            170
          ],
          "renderOrigin": [
            0.5,
            0.85
          ],
          "mouth": [
            26,
            117
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "ugryzienie_bok_2",
          "file": "lesny/ugryzienie_bok_2.png",
          "direction": "bok",
          "index": 2,
          "sourceBox": [
            559,
            21,
            471,
            312
          ],
          "sourceAnchor": [
            794.5,
            332
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            170
          ],
          "renderOrigin": [
            0.5,
            0.85
          ],
          "mouth": [
            14,
            124
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "ugryzienie_bok_3",
          "file": "lesny/ugryzienie_bok_3.png",
          "direction": "bok",
          "index": 3,
          "sourceBox": [
            1083,
            59,
            433,
            271
          ],
          "sourceAnchor": [
            1299.5,
            329
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            170
          ],
          "renderOrigin": [
            0.5,
            0.85
          ],
          "mouth": [
            24,
            116
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "ugryzienie_przod_1",
          "file": "lesny/ugryzienie_przod_1.png",
          "direction": "przod",
          "index": 1,
          "sourceBox": [
            52,
            356,
            415,
            301
          ],
          "sourceAnchor": [
            259.5,
            656
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            170
          ],
          "renderOrigin": [
            0.5,
            0.85
          ],
          "mouth": [
            110,
            152
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "ugryzienie_przod_2",
          "file": "lesny/ugryzienie_przod_2.png",
          "direction": "przod",
          "index": 2,
          "sourceBox": [
            565,
            352,
            415,
            304
          ],
          "sourceAnchor": [
            772.5,
            655
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            170
          ],
          "renderOrigin": [
            0.5,
            0.85
          ],
          "mouth": [
            110,
            151
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "ugryzienie_przod_3",
          "file": "lesny/ugryzienie_przod_3.png",
          "direction": "przod",
          "index": 3,
          "sourceBox": [
            1075,
            352,
            415,
            306
          ],
          "sourceAnchor": [
            1282.5,
            657
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            170
          ],
          "renderOrigin": [
            0.5,
            0.85
          ],
          "mouth": [
            110,
            150
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "ugryzienie_tyl_1",
          "file": "lesny/ugryzienie_tyl_1.png",
          "direction": "tyl",
          "index": 1,
          "sourceBox": [
            22,
            671,
            451,
            301
          ],
          "sourceAnchor": [
            247.5,
            971
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            159
          ],
          "renderOrigin": [
            0.5,
            0.795
          ],
          "mouth": [
            110,
            53
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "ugryzienie_tyl_2",
          "file": "lesny/ugryzienie_tyl_2.png",
          "direction": "tyl",
          "index": 2,
          "sourceBox": [
            546,
            668,
            464,
            310
          ],
          "sourceAnchor": [
            778.0,
            977
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            157
          ],
          "renderOrigin": [
            0.5,
            0.785
          ],
          "mouth": [
            110,
            50
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "ugryzienie_tyl_3",
          "file": "lesny/ugryzienie_tyl_3.png",
          "direction": "tyl",
          "index": 3,
          "sourceBox": [
            1064,
            667,
            439,
            308
          ],
          "sourceAnchor": [
            1283.5,
            974
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            158
          ],
          "renderOrigin": [
            0.5,
            0.79
          ],
          "mouth": [
            110,
            50
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        }
      ]
    },
    "trujacy": {
      "action": "dmuch",
      "atlas": "trujacy/atlas.png",
      "atlasSize": [
        660,
        600
      ],
      "scaleFromSource": 0.4020100502512563,
      "anchorType": "feet",
      "frames": [
        {
          "name": "dmuch_bok_1",
          "file": "trujacy/dmuch_bok_1.png",
          "direction": "bok",
          "index": 1,
          "sourceBox": [
            18,
            35,
            383,
            331
          ],
          "sourceAnchor": [
            209.5,
            365
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            170
          ],
          "renderOrigin": [
            0.5,
            0.85
          ],
          "mouth": [
            39,
            142
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "dmuch_bok_2",
          "file": "trujacy/dmuch_bok_2.png",
          "direction": "bok",
          "index": 2,
          "sourceBox": [
            432,
            42,
            421,
            327
          ],
          "sourceAnchor": [
            642.5,
            368
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            170
          ],
          "renderOrigin": [
            0.5,
            0.85
          ],
          "mouth": [
            28,
            129
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "dmuch_bok_3",
          "file": "trujacy/dmuch_bok_3.png",
          "direction": "bok",
          "index": 3,
          "sourceBox": [
            869,
            36,
            365,
            335
          ],
          "sourceAnchor": [
            1051.5,
            370
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            170
          ],
          "renderOrigin": [
            0.5,
            0.85
          ],
          "mouth": [
            43,
            143
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "dmuch_przod_1",
          "file": "trujacy/dmuch_przod_1.png",
          "direction": "przod",
          "index": 1,
          "sourceBox": [
            34,
            408,
            352,
            369
          ],
          "sourceAnchor": [
            210.0,
            776
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            170
          ],
          "renderOrigin": [
            0.5,
            0.85
          ],
          "mouth": [
            110,
            148
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "dmuch_przod_2",
          "file": "trujacy/dmuch_przod_2.png",
          "direction": "przod",
          "index": 2,
          "sourceBox": [
            455,
            405,
            359,
            372
          ],
          "sourceAnchor": [
            634.5,
            776
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            170
          ],
          "renderOrigin": [
            0.5,
            0.85
          ],
          "mouth": [
            110,
            148
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "dmuch_przod_3",
          "file": "trujacy/dmuch_przod_3.png",
          "direction": "przod",
          "index": 3,
          "sourceBox": [
            879,
            408,
            347,
            369
          ],
          "sourceAnchor": [
            1052.5,
            776
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            170
          ],
          "renderOrigin": [
            0.5,
            0.85
          ],
          "mouth": [
            110,
            148
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "dmuch_tyl_1",
          "file": "trujacy/dmuch_tyl_1.png",
          "direction": "tyl",
          "index": 1,
          "sourceBox": [
            47,
            825,
            353,
            376
          ],
          "sourceAnchor": [
            223.5,
            1200
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            150
          ],
          "renderOrigin": [
            0.5,
            0.75
          ],
          "mouth": [
            110,
            31
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "dmuch_tyl_2",
          "file": "trujacy/dmuch_tyl_2.png",
          "direction": "tyl",
          "index": 2,
          "sourceBox": [
            455,
            804,
            358,
            399
          ],
          "sourceAnchor": [
            634.0,
            1202
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            149
          ],
          "renderOrigin": [
            0.5,
            0.745
          ],
          "mouth": [
            110,
            23
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "dmuch_tyl_3",
          "file": "trujacy/dmuch_tyl_3.png",
          "direction": "tyl",
          "index": 3,
          "sourceBox": [
            876,
            823,
            359,
            384
          ],
          "sourceAnchor": [
            1055.5,
            1206
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            147
          ],
          "renderOrigin": [
            0.5,
            0.735
          ],
          "mouth": [
            110,
            28
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        }
      ]
    },
    "cien": {
      "action": "ziej",
      "atlas": "cien/atlas.png",
      "atlasSize": [
        660,
        600
      ],
      "scaleFromSource": 0.3883495145631068,
      "anchorType": "feet",
      "frames": [
        {
          "name": "ziej_bok_1",
          "file": "cien/ziej_bok_1.png",
          "direction": "bok",
          "index": 1,
          "sourceBox": [
            64,
            28,
            424,
            286
          ],
          "sourceAnchor": [
            276.0,
            313
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            170
          ],
          "renderOrigin": [
            0.5,
            0.85
          ],
          "mouth": [
            40,
            103
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "ziej_bok_2",
          "file": "cien/ziej_bok_2.png",
          "direction": "bok",
          "index": 2,
          "sourceBox": [
            563,
            26,
            418,
            287
          ],
          "sourceAnchor": [
            772.0,
            312
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            170
          ],
          "renderOrigin": [
            0.5,
            0.85
          ],
          "mouth": [
            32,
            109
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "ziej_bok_3",
          "file": "cien/ziej_bok_3.png",
          "direction": "bok",
          "index": 3,
          "sourceBox": [
            1073,
            59,
            439,
            254
          ],
          "sourceAnchor": [
            1292.5,
            312
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            170
          ],
          "renderOrigin": [
            0.5,
            0.85
          ],
          "mouth": [
            32,
            121
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "ziej_przod_1",
          "file": "cien/ziej_przod_1.png",
          "direction": "przod",
          "index": 1,
          "sourceBox": [
            44,
            322,
            417,
            307
          ],
          "sourceAnchor": [
            252.5,
            628
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            170
          ],
          "renderOrigin": [
            0.5,
            0.85
          ],
          "mouth": [
            110,
            152
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "ziej_przod_2",
          "file": "cien/ziej_przod_2.png",
          "direction": "przod",
          "index": 2,
          "sourceBox": [
            505,
            332,
            515,
            297
          ],
          "sourceAnchor": [
            762.5,
            628
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            170
          ],
          "renderOrigin": [
            0.5,
            0.85
          ],
          "mouth": [
            110,
            153
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "ziej_przod_3",
          "file": "cien/ziej_przod_3.png",
          "direction": "przod",
          "index": 3,
          "sourceBox": [
            1082,
            331,
            397,
            297
          ],
          "sourceAnchor": [
            1280.5,
            627
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            170
          ],
          "renderOrigin": [
            0.5,
            0.85
          ],
          "mouth": [
            110,
            153
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "ziej_tyl_1",
          "file": "cien/ziej_tyl_1.png",
          "direction": "tyl",
          "index": 1,
          "sourceBox": [
            35,
            642,
            430,
            351
          ],
          "sourceAnchor": [
            250.0,
            992
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            148
          ],
          "renderOrigin": [
            0.5,
            0.74
          ],
          "mouth": [
            110,
            45
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "ziej_tyl_2",
          "file": "cien/ziej_tyl_2.png",
          "direction": "tyl",
          "index": 2,
          "sourceBox": [
            521,
            624,
            505,
            376
          ],
          "sourceAnchor": [
            773.5,
            999
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            145
          ],
          "renderOrigin": [
            0.5,
            0.725
          ],
          "mouth": [
            110,
            36
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        },
        {
          "name": "ziej_tyl_3",
          "file": "cien/ziej_tyl_3.png",
          "direction": "tyl",
          "index": 3,
          "sourceBox": [
            1088,
            647,
            400,
            344
          ],
          "sourceAnchor": [
            1288.0,
            990
          ],
          "anchor": [
            110,
            170
          ],
          "renderAnchor": [
            110,
            149
          ],
          "renderOrigin": [
            0.5,
            0.745
          ],
          "mouth": [
            110,
            48
          ],
          "mouthPrecision": "approximate; check effect alignment in game"
        }
      ]
    }
  }
}
;
